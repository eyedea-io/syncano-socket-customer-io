"use strict";

var cov_2kzxvo042p = function () {
  var path = "/Users/user/Documents/GitHub/syncano/syncano-socket-customer-io/src/customer.ts",
      hash = "69cfc84da9fc9704f6bc3e94bfa07d8050ac8040",
      Function = function () {}.constructor,
      global = new Function('return this')(),
      gcv = "__coverage__",
      coverageData = {
    path: "/Users/user/Documents/GitHub/syncano/syncano-socket-customer-io/src/customer.ts",
    statementMap: {
      "0": {
        start: {
          line: 16,
          column: 16
        },
        end: {
          line: 16,
          column: 62
        }
      },
      "1": {
        start: {
          line: 17,
          column: 32
        },
        end: {
          line: 17,
          column: 36
        }
      },
      "2": {
        start: {
          line: 18,
          column: 23
        },
        end: {
          line: 18,
          column: 80
        }
      },
      "3": {
        start: {
          line: 20,
          column: 4
        },
        end: {
          line: 39,
          column: 5
        }
      },
      "4": {
        start: {
          line: 21,
          column: 6
        },
        end: {
          line: 25,
          column: 8
        }
      },
      "5": {
        start: {
          line: 27,
          column: 6
        },
        end: {
          line: 31,
          column: 7
        }
      },
      "6": {
        start: {
          line: 28,
          column: 8
        },
        end: {
          line: 30,
          column: 31
        }
      },
      "7": {
        start: {
          line: 33,
          column: 6
        },
        end: {
          line: 36,
          column: 8
        }
      },
      "8": {
        start: {
          line: 38,
          column: 6
        },
        end: {
          line: 38,
          column: 48
        }
      },
      "9": {
        start: {
          line: 44,
          column: 22
        },
        end: {
          line: 44,
          column: 39
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 12,
            column: 2
          },
          end: {
            line: 12,
            column: 3
          }
        },
        loc: {
          start: {
            line: 15,
            column: 4
          },
          end: {
            line: 40,
            column: 3
          }
        },
        line: 15
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 44,
            column: 15
          },
          end: {
            line: 44,
            column: 16
          }
        },
        loc: {
          start: {
            line: 44,
            column: 22
          },
          end: {
            line: 44,
            column: 39
          }
        },
        line: 44
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 18,
            column: 23
          },
          end: {
            line: 18,
            column: 80
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 18,
            column: 23
          },
          end: {
            line: 18,
            column: 38
          }
        }, {
          start: {
            line: 18,
            column: 42
          },
          end: {
            line: 18,
            column: 80
          }
        }],
        line: 18
      },
      "1": {
        loc: {
          start: {
            line: 23,
            column: 9
          },
          end: {
            line: 23,
            column: 45
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 23,
            column: 28
          },
          end: {
            line: 23,
            column: 40
          }
        }, {
          start: {
            line: 23,
            column: 43
          },
          end: {
            line: 23,
            column: 45
          }
        }],
        line: 23
      },
      "2": {
        loc: {
          start: {
            line: 27,
            column: 6
          },
          end: {
            line: 31,
            column: 7
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 27,
            column: 6
          },
          end: {
            line: 31,
            column: 7
          }
        }, {
          start: {
            line: 27,
            column: 6
          },
          end: {
            line: 31,
            column: 7
          }
        }],
        line: 27
      },
      "3": {
        loc: {
          start: {
            line: 34,
            column: 17
          },
          end: {
            line: 34,
            column: 95
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 34,
            column: 36
          },
          end: {
            line: 34,
            column: 64
          }
        }, {
          start: {
            line: 34,
            column: 67
          },
          end: {
            line: 34,
            column: 95
          }
        }],
        line: 34
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0
    },
    f: {
      "0": 0,
      "1": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0]
    },
    _coverageSchema: "332fd63041d2c1bcb487cc26dd0d5f7d97098a6c"
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var S = _interopRequireWildcard(require("@eyedea/syncano"));

var crypto = _interopRequireWildcard(require("crypto"));

var _customerioNode = _interopRequireDefault(require("customerio-node"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Endpoint extends (S.Endpoint) {
  async run({
    response,
    users
  }, {
    args,
    config
  }) {
    cov_2kzxvo042p.f[0]++;
    const cio = (cov_2kzxvo042p.s[0]++, new _customerioNode.default(config.SITE_ID, config.API_KEY));
    const {
      email,
      attributes
    } = (cov_2kzxvo042p.s[1]++, args);
    const customerId = (cov_2kzxvo042p.s[2]++, (cov_2kzxvo042p.b[0][0]++, args.customerId) || (cov_2kzxvo042p.b[0][1]++, crypto.randomBytes(16).toString('hex')));
    cov_2kzxvo042p.s[3]++;

    try {
      cov_2kzxvo042p.s[4]++;
      await cio.identify(customerId, _objectSpread({
        email,
        [!args.customerId ? (cov_2kzxvo042p.b[1][0]++, 'created_at') : (cov_2kzxvo042p.b[1][1]++, '')]: Math.round(new Date().getTime() / 1000)
      }, attributes));
      cov_2kzxvo042p.s[5]++;

      if (!args.customerId) {
        cov_2kzxvo042p.b[2][0]++;
        cov_2kzxvo042p.s[6]++;
        users.where('username', email).update({
          customerId
        });
      } else {
        cov_2kzxvo042p.b[2][1]++;
      }

      cov_2kzxvo042p.s[7]++;
      response.json({
        message: !args.customerId ? (cov_2kzxvo042p.b[3][0]++, 'Customer has been created.') : (cov_2kzxvo042p.b[3][1]++, 'Customer has been updated.'),
        customerId
      });
    } catch (err) {
      cov_2kzxvo042p.s[8]++;
      response.json({
        message: err.message
      }, 400);
    }
  }

}

var _default = ctx => {
  cov_2kzxvo042p.f[1]++;
  cov_2kzxvo042p.s[9]++;
  return new Endpoint(ctx);
};

exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jdXN0b21lci50cyJdLCJuYW1lcyI6WyJFbmRwb2ludCIsIlMiLCJydW4iLCJyZXNwb25zZSIsInVzZXJzIiwiYXJncyIsImNvbmZpZyIsImNpbyIsIkN1c3RvbWVySW8iLCJTSVRFX0lEIiwiQVBJX0tFWSIsImVtYWlsIiwiYXR0cmlidXRlcyIsImN1c3RvbWVySWQiLCJjcnlwdG8iLCJyYW5kb21CeXRlcyIsInRvU3RyaW5nIiwiaWRlbnRpZnkiLCJNYXRoIiwicm91bmQiLCJEYXRlIiwiZ2V0VGltZSIsIndoZXJlIiwidXBkYXRlIiwianNvbiIsIm1lc3NhZ2UiLCJlcnIiLCJjdHgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7O0FBQ0E7O0FBQ0E7Ozs7Ozs7Ozs7QUFRQSxNQUFNQSxRQUFOLFVBQXVCQyxDQUFDLENBQUNELFFBQXpCLEVBQWtDO0FBQ2hDLFFBQU1FLEdBQU4sQ0FDRTtBQUFDQyxJQUFBQSxRQUFEO0FBQVdDLElBQUFBO0FBQVgsR0FERixFQUVFO0FBQUNDLElBQUFBLElBQUQ7QUFBT0MsSUFBQUE7QUFBUCxHQUZGLEVBR0U7QUFBQTtBQUNBLFVBQU1DLEdBQUcsMkJBQUcsSUFBSUMsdUJBQUosQ0FBZUYsTUFBTSxDQUFDRyxPQUF0QixFQUErQkgsTUFBTSxDQUFDSSxPQUF0QyxDQUFILENBQVQ7QUFDQSxVQUFNO0FBQUNDLE1BQUFBLEtBQUQ7QUFBUUMsTUFBQUE7QUFBUixnQ0FBc0JQLElBQXRCLENBQU47QUFDQSxVQUFNUSxVQUFVLDJCQUFHLDJCQUFBUixJQUFJLENBQUNRLFVBQUwsZ0NBQW1CQyxNQUFNLENBQUNDLFdBQVAsQ0FBbUIsRUFBbkIsRUFBdUJDLFFBQXZCLENBQWdDLEtBQWhDLENBQW5CLENBQUgsQ0FBaEI7QUFIQTs7QUFLQSxRQUFJO0FBQUE7QUFDRixZQUFNVCxHQUFHLENBQUNVLFFBQUosQ0FBYUosVUFBYjtBQUNKRixRQUFBQSxLQURJO0FBRUosU0FBQyxDQUFDTixJQUFJLENBQUNRLFVBQU4sOEJBQW1CLFlBQW5CLCtCQUFrQyxFQUFsQyxDQUFELEdBQXdDSyxJQUFJLENBQUNDLEtBQUwsQ0FBWSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsT0FBYixLQUF5QixJQUFwQztBQUZwQyxTQUdEVCxVQUhDLEVBQU47QUFERTs7QUFPRixVQUFJLENBQUNQLElBQUksQ0FBQ1EsVUFBVixFQUFzQjtBQUFBO0FBQUE7QUFDcEJULFFBQUFBLEtBQUssQ0FDRmtCLEtBREgsQ0FDUyxVQURULEVBQ3FCWCxLQURyQixFQUVHWSxNQUZILENBRVU7QUFBQ1YsVUFBQUE7QUFBRCxTQUZWO0FBR0QsT0FKRDtBQUFBO0FBQUE7O0FBUEU7QUFhRlYsTUFBQUEsUUFBUSxDQUFDcUIsSUFBVCxDQUFjO0FBQ1pDLFFBQUFBLE9BQU8sRUFBRSxDQUFDcEIsSUFBSSxDQUFDUSxVQUFOLDhCQUFtQiw0QkFBbkIsK0JBQWtELDRCQUFsRCxDQURHO0FBRVpBLFFBQUFBO0FBRlksT0FBZDtBQUlELEtBakJELENBaUJFLE9BQU9hLEdBQVAsRUFBWTtBQUFBO0FBQ1p2QixNQUFBQSxRQUFRLENBQUNxQixJQUFULENBQWM7QUFBQ0MsUUFBQUEsT0FBTyxFQUFFQyxHQUFHLENBQUNEO0FBQWQsT0FBZCxFQUFzQyxHQUF0QztBQUNEO0FBQ0Y7O0FBN0IrQjs7ZUFpQ25CRSxHQUFHLElBQUk7QUFBQTtBQUFBO0FBQUEsYUFBSTNCLFFBQUosQ0FBYTJCLEdBQWI7QUFBaUIsQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFMgZnJvbSAnQGV5ZWRlYS9zeW5jYW5vJ1xuaW1wb3J0ICogYXMgY3J5cHRvIGZyb20gJ2NyeXB0bydcbmltcG9ydCBDdXN0b21lcklvIGZyb20gJ2N1c3RvbWVyaW8tbm9kZSdcblxuaW50ZXJmYWNlIEFyZ3Mge1xuICBjdXN0b21lcklkPzogc3RyaW5nXG4gIGVtYWlsOiBzdHJpbmdcbiAgYXR0cmlidXRlczogb2JqZWN0XG59XG5cbmNsYXNzIEVuZHBvaW50IGV4dGVuZHMgUy5FbmRwb2ludCB7XG4gIGFzeW5jIHJ1bihcbiAgICB7cmVzcG9uc2UsIHVzZXJzfTogUy5Db3JlLFxuICAgIHthcmdzLCBjb25maWd9OiBTLkNvbnRleHQ8QXJncz5cbiAgKSB7XG4gICAgY29uc3QgY2lvID0gbmV3IEN1c3RvbWVySW8oY29uZmlnLlNJVEVfSUQsIGNvbmZpZy5BUElfS0VZKVxuICAgIGNvbnN0IHtlbWFpbCwgYXR0cmlidXRlc30gPSBhcmdzXG4gICAgY29uc3QgY3VzdG9tZXJJZCA9IGFyZ3MuY3VzdG9tZXJJZCB8fCBjcnlwdG8ucmFuZG9tQnl0ZXMoMTYpLnRvU3RyaW5nKCdoZXgnKVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGNpby5pZGVudGlmeShjdXN0b21lcklkLCB7XG4gICAgICAgIGVtYWlsLFxuICAgICAgICBbIWFyZ3MuY3VzdG9tZXJJZCA/ICdjcmVhdGVkX2F0JyA6ICcnXTogTWF0aC5yb3VuZCgobmV3IERhdGUoKSkuZ2V0VGltZSgpIC8gMTAwMCksXG4gICAgICAgIC4uLmF0dHJpYnV0ZXMsXG4gICAgICB9KVxuXG4gICAgICBpZiAoIWFyZ3MuY3VzdG9tZXJJZCkge1xuICAgICAgICB1c2Vyc1xuICAgICAgICAgIC53aGVyZSgndXNlcm5hbWUnLCBlbWFpbClcbiAgICAgICAgICAudXBkYXRlKHtjdXN0b21lcklkfSlcbiAgICAgIH1cblxuICAgICAgcmVzcG9uc2UuanNvbih7XG4gICAgICAgIG1lc3NhZ2U6ICFhcmdzLmN1c3RvbWVySWQgPyAnQ3VzdG9tZXIgaGFzIGJlZW4gY3JlYXRlZC4nIDogJ0N1c3RvbWVyIGhhcyBiZWVuIHVwZGF0ZWQuJyxcbiAgICAgICAgY3VzdG9tZXJJZCxcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICByZXNwb25zZS5qc29uKHttZXNzYWdlOiBlcnIubWVzc2FnZX0sIDQwMClcbiAgICB9XG4gIH1cblxufVxuXG5leHBvcnQgZGVmYXVsdCBjdHggPT4gbmV3IEVuZHBvaW50KGN0eClcbiJdfQ==